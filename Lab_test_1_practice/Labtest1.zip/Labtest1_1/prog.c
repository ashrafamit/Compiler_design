#include<math.h> 
#define INTEGER int 

int main() 
{ 
   INTEGER a=10; 
   INTEGER b=20; 
   return 0;
} 
